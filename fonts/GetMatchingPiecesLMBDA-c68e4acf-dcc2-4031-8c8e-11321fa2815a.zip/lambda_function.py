import json 
import boto3

client = boto3.client("bedrock-runtime")


#Calls bedrock to allow user to upload description of clothing and returns three sugguestions 
def lambda_handler(event, context):
    body = json.loads(event.get("body", "{}"))
    user_input = body.get("input", "")

    prompt = f"You are a fashion designer. Based on this clothing description: {user_input}, suggest 3 pieces of clothing that would pair well with it."

    response = client.invoke_model(
        modelId="anthropic.claude-3-haiku-20240307-v1:0",
        body=json.dumps({
            "anthropic_version": "bedrock-2023-05-31",
            "messages": [{"role": "user", "content": prompt}],
            "max_tokens": 1000,
        })
    )

    suggestions = json.loads(response.get("body").read())["content"][0]['text']

    #generating images with Titan 
    descriptions = suggestions.strip().split("\n\n")
    images = []

    for desc in descriptions[:3]:
        img_prompt = f"A product photo of {desc}, on a clean white background, studio lighting, high quality fashion photography"
        img_response = client.invoke_model(
            modelId = "amazon.titan-image-generator-v2:0", 
            body = json.dumps({
                "textToImageParams": {"text": img_prompt}, 
                "taskType": "TEXT_IMAGE", 
                "imageGenerationConfig": {
                    "numberOfImages": 1,
                    "height": 512,
                    "width": 512,
                }

            })
        )
        img_data = json.loads(img_response["body"].read())
        images.append(img_data["images"][0])

    # return results as renderable html
    html = "<html><body><h2>Suggestions</h2><p>{}</p><h2>Generated Images</h2>".format(suggestions.replace('\n', '<br/>'))
    for i, img in enumerate(images):
        html += f"<img src='data:image/png;base64,{img}' alt='Generated Image {i+1}' style='width:256px;height:256px;'><br/>"
    html += "</body></html>"

    return {
        "statusCode": 200,
        "headers": {
            "Content-Type": "text/html",
        },
        "body": html,
    }

    